#!/bin/bash
set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "🚀 Instalowanie Galaxy Terminal..."

if [ ! -f "$SCRIPT_DIR/galaxy-term" ]; then
    echo "❌ Błąd: Brak pliku galaxy-term w folderze instalatora!"
    exit 1
fi

mkdir -p ~/.local/bin
mkdir -p ~/.local/share/applications
mkdir -p ~/.local/share/icons/hicolor/scalable/apps

cp "$SCRIPT_DIR/galaxy-term" ~/.local/bin/
chmod +x ~/.local/bin/galaxy-term
cp "$SCRIPT_DIR/galaxy-term.svg" ~/.local/share/icons/hicolor/scalable/apps/

# Bezwzględna ścieżka w .desktop, żeby menu na 100% działało
cat > ~/.local/share/applications/galaxy-term.desktop << DESKTOP_EOF
[Desktop Entry]
Name=Galaxy Terminal
GenericName=Terminal
Comment=A sleek macOS-style terminal
Exec=$HOME/.local/bin/galaxy-term
Icon=galaxy-term
Terminal=false
Type=Application
Categories=System;TerminalEmulator;
Keywords=terminal;shell;console;galaxy;macos;
StartupNotify=true
DESKTOP_EOF

update-desktop-database ~/.local/share/applications/ 2>/dev/null || true
gtk-update-icon-cache ~/.local/share/icons/hicolor 2>/dev/null || true

if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
    echo "⚠️  Dodano ~/.local/bin do PATH. Wpisz 'source ~/.zshrc' aby użyć komendy w tej sesji."
fi

echo "✅ Sukces! Możesz uruchomić 'Galaxy Terminal' z menu."
